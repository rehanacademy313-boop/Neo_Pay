import Layout from "../components/Layout";

const history = [
  { id: "TXN746454552", amount: 3000, profit: 150, at: "30/08/2025, 13:30" },
  { id: "TXN100972328", amount: 1000, profit: 50, at: "30/08/2025, 13:32" },
];

export default function History() {
  return (
    <Layout>
      <h2 className="text-lg font-semibold mb-4">Transaction History</h2>
      <div className="space-y-3">
        {history.map((h) => (
          <div
            key={h.id}
            className="p-4 rounded-xl bg-white shadow flex justify-between"
          >
            <div>
              <p className="font-bold">₹{h.amount}</p>
              <p className="text-xs text-gray-500">Profit: ₹{h.profit}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-mono">{h.id}</p>
              <p className="text-xs text-gray-400">{h.at}</p>
            </div>
          </div>
        ))}
      </div>
    </Layout>
  );
}