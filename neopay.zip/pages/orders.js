import Layout from "../components/Layout";

const products = [
  { id: 1, price: 300, reward: 15, quota: 315 },
  { id: 2, price: 333, reward: 15.99, quota: 348.99 },
  { id: 3, price: 49999, reward: 1505.97, quota: 51504.97 },
];

export default function Orders() {
  return (
    <Layout>
      <h2 className="text-lg font-semibold mb-4">Orders</h2>
      <div className="space-y-3">
        {products.map((p) => (
          <div
            key={p.id}
            className="p-4 rounded-xl bg-white shadow flex justify-between"
          >
            <div>
              <p className="font-bold">₹{p.price}</p>
              <p className="text-xs text-gray-500">Reward ₹{p.reward}</p>
              <p className="text-xs text-emerald-600">Quota + ₹{p.quota}</p>
            </div>
            <button className="px-3 py-1 rounded-lg bg-emerald-500 text-white">
              Buy
            </button>
          </div>
        ))}
      </div>
    </Layout>
  );
}