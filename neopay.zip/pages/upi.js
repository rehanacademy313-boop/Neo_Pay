import Layout from "../components/Layout";

export default function UPI() {
  const vpa = "yourname@bank";
  const upiUrl = \`upi://pay?pa=\${vpa}&pn=NeoPay&am=300&cu=INR\`;

  return (
    <Layout>
      <h2 className="text-lg font-semibold mb-4">UPI Payment (Demo)</h2>
      <p className="text-sm text-gray-500 mb-2">
        This generates a demo UPI intent link (not real money).
      </p>
      <a
        href={upiUrl}
        className="px-4 py-2 bg-emerald-500 text-white rounded-lg"
      >
        Pay ₹300 via UPI
      </a>
      <p className="text-xs text-gray-400 mt-2 break-all">{upiUrl}</p>
    </Layout>
  );
}