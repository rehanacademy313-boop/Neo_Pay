import Layout from "../components/Layout";

export default function Profile() {
  return (
    <Layout>
      <h2 className="text-lg font-semibold mb-4">My Profile</h2>
      <div className="p-4 bg-white shadow rounded-xl">
        <p className="font-bold">User: rexhan@neopay</p>
        <p className="text-xs text-gray-500">Dhubri ⇄ Guwahati</p>
        <p className="mt-2 text-xs text-gray-400">
          (Demo only – connect backend & KYC here)
        </p>
      </div>
    </Layout>
  );
}