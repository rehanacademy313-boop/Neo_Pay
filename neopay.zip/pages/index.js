import Layout from "../components/Layout";

export default function Home() {
  return (
    <Layout>
      <h2 className="text-lg font-semibold mb-2">Welcome to NeoPay</h2>
      <p className="text-sm text-gray-600">
        Manage your balance, buy orders, track history, and pay via UPI.
      </p>
    </Layout>
  );
}