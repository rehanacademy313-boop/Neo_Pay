import Link from "next/link";
import { useRouter } from "next/router";

export default function Layout({ children }) {
  const router = useRouter();
  const tabs = [
    { href: "/", label: "Home" },
    { href: "/orders", label: "Orders" },
    { href: "/upi", label: "UPI" },
    { href: "/history", label: "History" },
    { href: "/profile", label: "Profile" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="p-4 bg-white shadow">
        <h1 className="text-xl font-bold text-emerald-600">NeoPay</h1>
        <p className="text-xs text-gray-500">Secure Orders · UPI Ready</p>
      </header>

      <main className="flex-1 p-4">{children}</main>

      <nav className="grid grid-cols-5 border-t bg-white text-sm">
        {tabs.map((tab) => (
          <Link
            key={tab.href}
            href={tab.href}
            className={\`p-2 text-center \${router.pathname === tab.href ? "text-emerald-600 font-bold" : "text-gray-500"}\`}
          >
            {tab.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}